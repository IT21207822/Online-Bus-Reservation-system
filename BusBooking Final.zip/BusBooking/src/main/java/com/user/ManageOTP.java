package com.user;

public class ManageOTP {
	private static String otp;
	private static String email;
	
	public void setOTP(String otp) {
		ManageOTP.otp = otp;
	}
	
	public String getOtp() {
		return otp;
	}
	
	public void setEmail(String otp) {
		ManageOTP.email = otp;
	}
	
	public String getEmail() {
		return email;
	}

}
